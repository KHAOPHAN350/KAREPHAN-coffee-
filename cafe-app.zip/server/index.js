const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const admin = require('firebase-admin');
const serviceAccount = require('./firebase-adminsdk.json');
const authRoutes = require('./routes/auth');
const orderRoutes = require('./routes/order');
const deliveryRoutes = require('./routes/delivery');

const app = express();
app.use(cors());
app.use(express.json());

// ตั้งค่า Firebase
admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
});

// เชื่อมต่อ MongoDB
mongoose.connect('mongodb://localhost/cafe-app', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

// Middleware สำหรับตรวจสอบ JWT
const authenticate = (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ message: 'Unauthorized' });
  try {
    const decoded = jwt.verify(token, 'secret-key');
    req.user = decoded;
    next();
  } catch (error) {
    res.status(401).json({ message: 'Invalid token' });
  }
};

app.use('/auth', authRoutes);
app.use('/order', authenticate, orderRoutes);
app.use('/delivery', authenticate, deliveryRoutes);

app.listen(5000, () => console.log('Server running on port 5000'));