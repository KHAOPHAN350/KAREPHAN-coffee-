const express = require('express');
const mongoose = require('mongoose');
const Order = require('../models/Order');
const admin = require('firebase-admin');
const router = express.Router();

const Menu = mongoose.model('Menu', new mongoose.Schema({
  name: String,
  description: String,
  price: Number,
  image: String,
}));

router.get('/menu', async (req, res) => {
  try {
    const menuItems = await Menu.find();
    res.json(menuItems);
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch menu', error });
  }
});

router.post('/menu', async (req, res) => {
  try {
    const menuItem = new Menu(req.body);
    await menuItem.save();
    res.json(menuItem);
  } catch (error) {
    res.status(500).json({ message: 'Failed to add menu item', error });
  }
});

router.post('/', async (req, res) => {
  try {
    const order = new Order({
      ...req.body,
      customerId: req.user.id,
    });
    await order.save();
    const cashier = await User.findOne({ role: 'cashier' });
    if (cashier?.notificationToken) {
      admin.messaging().send({
        token: cashier.notificationToken,
        notification: {
          title: 'New Order',
          body: `Order #${order._id} received`,
        },
      });
    }
    res.json({ orderId: order._id });
  } catch (error) {
    res.status(500).json({ message: 'Order creation failed', error });
  }
});

router.get('/:orderId', async (req, res) => {
  try {
    const order = await Order.findById(req.params.orderId);
    if (!order) return res.status(404).json({ message: 'Order not found' });
    res.json(order);
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch order', error });
  }
});

router.get('/', async (req, res) => {
  try {
    const orders = await Order.find();
    res.json(orders);
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch orders', error });
  }
});

router.put('/confirm/:orderId', async (req, res) => {
  try {
    const order = await Order.findById(req.params.orderId);
    if (!order) return res.status(404).json({ message: 'Order not found' });
    order.status = 'preparing';
    order.barcode = `order-${order._id}-${Date.now()}`;
    await order.save();
    const delivery = await User.findOne({ role: 'delivery' });
    if (delivery?.notificationToken) {
      admin.messaging().send({
        token: delivery.notificationToken,
        notification: {
          title: 'Order Ready',
          body: `Order #${order._id} is ready for delivery`,
        },
      });
    }
    res.json(order);
  } catch (error) {
    res.status(500).json({ message: 'Failed to confirm order', error });
  }
});

module.exports = router;