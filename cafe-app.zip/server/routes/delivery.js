const express = require('express');
const Order = require('../models/Order');
const admin = require('firebase-admin');
const router = express.Router();

router.post('/scan', async (req, res) => {
  try {
    const { barcode } = req.body;
    const order = await Order.findOne({ barcode });
    if (!order) return res.status(404).json({ message: 'Order not found' });
    res.json({ orderId: order._id });
  } catch (error) {
    res.status(500).json({ message: 'Scan failed', error });
  }
});

router.post('/location', async (req, res) => {
  try {
    const { userId, location } = req.body;
    // Store location in database or memory (simplified)
    res.json({ message: 'Location updated' });
  } catch (error) {
    res.status(500).json({ message: 'Failed to update location', error });
  }
});

router.get('/location/:orderId', async (req, res) => {
  try {
    // Return mock delivery location (simplified)
    res.json({ lat: 13.7563, lng: 100.5018 });
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch location', error });
  }
});

router.put('/start/:orderId', async (req, res) => {
  try {
    const order = await Order.findById(req.params.orderId);
    if (!order) return res.status(404).json({ message: 'Order not found' });
    order.status = 'delivering';
    await order.save();
    res.json(order);
  } catch (error) {
    res.status(500).json({ message: 'Failed to start delivery', error });
  }
});

router.put('/complete/:orderId', async (req, res) => {
  try {
    const order = await Order.findById(req.params.orderId);
    if (!order) return res.status(404).json({ message: 'Order not found' });
    order.status = 'delivered';
    await order.save();
    const customer = await User.findById(order.customerId);
    if (customer?.notificationToken) {
      admin.messaging().send({
        token: customer.notificationToken,
        notification: {
          title: 'Order Delivered',
          body: `Your order #${order._id} has been delivered`,
        },
      });
    }
    res.json(order);
  } catch (error) {
    res.status(500).json({ message: 'Failed to complete delivery', error });
  }
});

module.exports = router;