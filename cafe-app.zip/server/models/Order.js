const mongoose = require('mongoose');

const orderSchema = new mongoose.Schema({
  customerId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  items: [
    {
      name: String,
      price: Number,
      quantity: Number,
    },
  ],
  name: String,
  phone: String,
  location: {
    lat: Number,
    lng: Number,
  },
  paymentMethod: { type: String, enum: ['cod', 'qrcode'], required: true },
  status: {
    type: String,
    enum: ['pending', 'preparing', 'delivering', 'delivered'],
    default: 'pending',
  },
  barcode: String,
});

module.exports = mongoose.model('Order', orderSchema);