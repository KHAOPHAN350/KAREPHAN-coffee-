import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Switch, Redirect } from 'react-router-dom';
import Login from './components/Login';
import Home from './components/Home';
import Order from './components/Order';
import OrderStatus from './components/OrderStatus';
import CashierDashboard from './components/CashierDashboard';
import AdminDashboard from './components/AdminDashboard';
import DeliveryDashboard from './components/DeliveryDashboard';
import firebase from 'firebase/app';
import 'firebase/messaging';
import './styles/styles.css';

const App = () => {
  const [user, setUser] = useState(null);

  const requestNotificationPermission = async () => {
    try {
      const permission = await Notification.requestPermission();
      if (permission === 'granted') {
        const token = await firebase.messaging().getToken();
        return token;
      }
      return null;
    } catch (error) {
      console.error('Error requesting notification permission:', error);
      return null;
    }
  };

  return (
    <Router>
      <Switch>
        <Route
          path="/login/:role"
          render={(props) => (
            <Login {...props} setUser={setUser} requestNotificationPermission={requestNotificationPermission} />
          )}
        />
        <Route
          path="/home"
          render={() => (user?.role === 'customer' ? <Home /> : <Redirect to="/login/customer" />)}
        />
        <Route
          path="/order"
          render={() => (user?.role === 'customer' ? <Order user={user} /> : <Redirect to="/login/customer" />)}
        />
        <Route
          path="/order-status/:orderId"
          render={() => (user?.role === 'customer' ? <OrderStatus /> : <Redirect to="/login/customer" />)}
        />
        <Route
          path="/cashier"
          render={() => (user?.role === 'cashier' ? <CashierDashboard /> : <Redirect to="/login/cashier" />)}
        />
        <Route
          path="/admin"
          render={() => (user?.role === 'admin' ? <AdminDashboard /> : <Redirect to="/login/admin" />)}
        />
        <Route
          path="/delivery"
          render={() => (user?.role === 'delivery' ? <DeliveryDashboard user={user} /> : <Redirect to="/login/delivery" />)}
        />
        <Redirect to="/login/customer" />
      </Switch>
    </Router>
  );
};

export default App;