import React, { useState, useEffect } from 'react';
import axios from 'axios';
import '../styles/styles.css';

const AdminDashboard = () => {
  const [menuItems, setMenuItems] = useState([]);
  const [newItem, setNewItem] = useState({ name: '', description: '', price: '', image: '' });

  useEffect(() => {
    axios
      .get('http://localhost:5000/order/menu', {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
      })
      .then((response) => {
        setMenuItems(response.data);
      });
  }, []);

  const handleInputChange = (e) => {
    setNewItem({ ...newItem, [e.target.name]: e.target.value });
  };

  const addMenuItem = async () => {
    try {
      const response = await axios.post(
        'http://localhost:5000/order/menu',
        newItem,
        { headers: { Authorization: `Bearer ${localStorage.getItem('token')}` } }
      );
      setMenuItems([...menuItems, response.data]);
      setNewItem({ name: '', description: '', price: '', image: '' });
    } catch (error) {
      console.error('Add menu item error:', error);
      alert('Failed to add menu item');
    }
  };

  return (
    <div className="admin-container">
      <h2 className="title black">Admin Dashboard</h2>
      <div className="menu-form">
        <h3>Add Menu Item</h3>
        <input
          type="text"
          name="name"
          placeholder="Name"
          value={newItem.name}
          onChange={handleInputChange}
          required
        />
        <input
          type="text"
          name="description"
          placeholder="Description"
          value={newItem.description}
          onChange={handleInputChange}
        />
        <input
          type="number"
          name="price"
          placeholder="Price"
          value={newItem.price}
          onChange={handleInputChange}
          required
        />
        <input
          type="text"
          name="image"
          placeholder="Image URL"
          value={newItem.image}
          onChange={handleInputChange}
        />
        <button onClick={addMenuItem}>Add Item</button>
      </div>
      <div className="menu-list">
        <h3>Menu Items</h3>
        <div className="menu-grid">
          {menuItems.map((item) => (
            <div className="menu-item" key={item._id}>
              <img src={item.image} alt={item.name} />
              <p>{item.name} - {item.price} THB</p>
              <p>{item.description}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;