import React, { useState, useEffect } from 'react';
import axios from 'axios';
import QRCode from 'qrcode.react';
import '../styles/styles.css';

const CashierDashboard = () => {
  const [orders, setOrders] = useState([]);

  useEffect(() => {
    axios
      .get('http://localhost:5000/order', {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
      })
      .then((response) => {
        setOrders(response.data);
      });
  }, []);

  const confirmOrder = async (orderId) => {
    try {
      await axios.put(
        `http://localhost:5000/order/confirm/${orderId}`,
        {},
        { headers: { Authorization: `Bearer ${localStorage.getItem('token')}` } }
      );
      setOrders(
        orders.map((order) =>
          order._id === orderId ? { ...order, status: 'preparing', barcode: `order-${orderId}-${Date.now()}` } : order
        )
      );
    } catch (error) {
      console.error('Confirm order error:', error);
      alert('Failed to confirm order');
    }
  };

  return (
    <div className="cashier-container">
      <h2 className="title black">Cashier Dashboard</h2>
      <div className="order-list">
        {orders.map((order) => (
          <div className="order-item" key={order._id}>
            <h3>Order #{order._id}</h3>
            <p>Customer: {order.name}</p>
            <p>Status: {order.status}</p>
            <div className="order-items">
              {order.items.map((item, index) => (
                <div key={index}>
                  {item.name} x {item.quantity} - {item.price * item.quantity} THB
                </div>
              ))}
            </div>
            {order.status === 'pending' && <button onClick={() => confirmOrder(order._id)}>Confirm Order</button>}
            {order.status === 'preparing' && order.barcode && (
              <div className="barcode">
                <p>Barcode: {order.barcode}</p>
                <QRCode value={order.barcode} />
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default CashierDashboard;