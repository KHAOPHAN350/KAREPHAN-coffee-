import React from 'react';
import { Link } from 'react-router-dom';
import '../styles/styles.css';

const Home = () => {
  return (
    <div className="home-container">
      <div className="home-content">
        <h1 className="title">Welcome to Nature Café</h1>
        <p className="description">Enjoy coffee and desserts in nature</p>
        <Link to="/order">
          <button className="order-button">Order Online</button>
        </Link>
      </div>
    </div>
  );
};

export default Home;