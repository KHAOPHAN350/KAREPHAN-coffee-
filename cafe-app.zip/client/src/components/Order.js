import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { GoogleMap, LoadScript, Marker } from '@react-google-maps/api';
import QRCode from 'qrcode.react';
import '../styles/styles.css';

const Order = ({ user }) => {
  const [menuItems, setMenuItems] = useState([]);
  const [order, setOrder] = useState([]);
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [location, setLocation] = useState({ lat: 13.7563, lng: 100.5018 });
  const [paymentMethod, setPaymentMethod] = useState('cod');
  const [orderId, setOrderId] = useState(null);

  useEffect(() => {
    axios.get('http://localhost:5000/order/menu').then((response) => {
      setMenuItems(response.data);
    });
  }, []);

  const addToOrder = (item) => {
    setOrder([...order, { ...item, quantity: 1 }]);
  };

  const removeFromOrder = (index) => {
    setOrder(order.filter((_, i) => i !== index));
  };

  const handleSubmit = async () => {
    try {
      const response = await axios.post(
        'http://localhost:5000/order',
        {
          customerId: user.id,
          items: order,
          name,
          phone,
          location,
          paymentMethod,
        },
        { headers: { Authorization: `Bearer ${localStorage.getItem('token')}` } }
      );
      setOrderId(response.data.orderId);
    } catch (error) {
      console.error('Order submission error:', error);
      alert('Order failed');
    }
  };

  return (
    <div className="order-container">
      <h2 className="title black">Order Online</h2>
      <div className="menu">
        <h3>Menu</h3>
        <div className="menu-grid">
          {menuItems.map((item) => (
            <div className="menu-item" key={item._id}>
              <img src={item.image} alt={item.name} />
              <h4>{item.name}</h4>
              <p>{item.description}</p>
              <p>{item.price} THB</p>
              <button onClick={() => addToOrder(item)}>Add to Order</button>
            </div>
          ))}
        </div>
      </div>
      <div className="summary">
        <h3>Order Summary</h3>
        {order.map((item, index) => (
          <div className="summary-item" key={index}>
            <span>
              {item.name} x {item.quantity}
            </span>
            <span>{item.price * item.quantity} THB</span>
            <button onClick={() => removeFromOrder(index)}>-</button>
          </div>
        ))}
        <p>Total: {order.reduce((sum, item) => sum + item.price * item.quantity, 0)} THB</p>
      </div>
      <div className="location">
        <h3>Delivery Location</h3>
        <LoadScript googleMapsApiKey="your-google-maps-api-key">
          <GoogleMap
            mapContainerStyle={{ height: '400px', width: '100%' }}
            center={location}
            zoom={15}
            onClick={(e) => setLocation({ lat: e.latLng.lat(), lng: e.latLng.lng() })}
          >
            <Marker position={location} />
          </GoogleMap>
        </LoadScript>
      </div>
      <div className="customer-info">
        <h3>Customer Information</h3>
        <input
          type="text"
          placeholder="Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
        />
        <input
          type="tel"
          placeholder="Phone"
          value={phone}
          onChange={(e) => setPhone(e.target.value)}
          required
        />
      </div>
      <div className="payment">
        <h3>Payment Method</h3>
        <label>
          <input
            type="radio"
            name="payment"
            value="cod"
            checked={paymentMethod === 'cod'}
            onChange={() => setPaymentMethod('cod')}
          />
          Cash on Delivery
        </label>
        <label>
          <input
            type="radio"
            name="payment"
            value="qrcode"
            checked={paymentMethod === 'qrcode'}
            onChange={() => setPaymentMethod('qrcode')}
          />
          QR Code (PromptPay)
        </label>
      </div>
      {paymentMethod === 'qrcode' && orderId && (
        <div className="qrcode">
          <h3>Scan QR Code to Pay</h3>
          <QRCode value={`order-${orderId}-${phone}`} />
          <button onClick={handleSubmit}>Confirm Payment</button>
        </div>
      )}
      <button className="submit-button" onClick={handleSubmit}>
        Confirm Order
      </button>
    </div>
  );
};

export default Order;