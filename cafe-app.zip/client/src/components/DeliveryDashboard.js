import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { GoogleMap, LoadScript, Marker } from '@react-google-maps/api';
import '../styles/styles.css';

const DeliveryDashboard = ({ user }) => {
  const [orders, setOrders] = useState([]);
  const [barcode, setBarcode] = useState('');
  const [deliveryLocation, setDeliveryLocation] = useState(null);

  useEffect(() => {
    axios
      .get('http://localhost:5000/order', {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
      })
      .then((response) => {
        setOrders(response.data.filter((order) => order.status === 'preparing' || order.status === 'delivering'));
      });

    if (navigator.geolocation) {
      navigator.geolocation.watchPosition((position) => {
        const location = { lat: position.coords.latitude, lng: position.coords.longitude };
        setDeliveryLocation(location);
        axios.post(
          'http://localhost:5000/delivery/location',
          { userId: user.id, location },
          { headers: { Authorization: `Bearer ${localStorage.getItem('token')}` } }
        );
      });
    }
  }, [user]);

  const scanBarcode = async () => {
    try {
      const response = await axios.post(
        'http://localhost:5000/delivery/scan',
        { barcode },
        { headers: { Authorization: `Bearer ${localStorage.getItem('token')}` } }
      );
      alert(`Order ${response.data.orderId} found`);
    } catch (error) {
      console.error('Scan error:', error);
      alert('Invalid barcode');
    }
  };

  const startDelivery = async (orderId) => {
    try {
      await axios.put(
        `http://localhost:5000/delivery/start/${orderId}`,
        {},
        { headers: { Authorization: `Bearer ${localStorage.getItem('token')}` } }
      );
      setOrders(
        orders.map((order) => (order._id === orderId ? { ...order, status: 'delivering' } : order))
      );
    } catch (error) {
      console.error('Start delivery error:', error);
      alert('Failed to start delivery');
    }
  };

  const completeDelivery = async (orderId) => {
    try {
      await axios.put(
        `http://localhost:5000/delivery/complete/${orderId}`,
        {},
        { headers: { Authorization: `Bearer ${localStorage.getItem('token')}` } }
      );
      setOrders(orders.filter((order) => order._id !== orderId));
    } catch (error) {
      console.error('Complete delivery error:', error);
      alert('Failed to complete delivery');
    }
  };

  return (
    <div className="delivery-container">
      <h2 className="title black">Delivery Dashboard</h2>
      <div className="barcode-scanner">
        <h3>Scan Barcode</h3>
        <input
          type="text"
          placeholder="Enter barcode"
          value={barcode}
          onChange={(e) => setBarcode(e.target.value)}
        />
        <button onClick={scanBarcode}>Scan</button>
      </div>
      {deliveryLocation && (
        <LoadScript googleMapsApiKey="your-google-maps-api-key">
          <GoogleMap
            mapContainerStyle={{ height: '400px', width: '100%' }}
            center={deliveryLocation}
            zoom={15}
          >
            <Marker position={deliveryLocation} label="You" />
          </GoogleMap>
        </LoadScript>
      )}
      <div className="order-list">
        {orders.map((order) => (
          <div className="order-item" key={order._id}>
            <h3>Order #{order._id}</h3>
            <p>Customer: {order.name}</p>
            <p>Status: {order.status}</p>
            <div className="order-items">
              {order.items.map((item, index) => (
                <div key={index}>
                  {item.name} x {item.quantity} - {item.price * item.quantity} THB
                </div>
              ))}
            </div>
            {order.status === 'preparing' && (
              <button onClick={() => startDelivery(order._id)}>Start Delivery</button>
            )}
            {order.status === 'delivering' && (
              <>
                <button
                  onClick={() => window.open(`tel:${order.phone}`, '_self')}
                >
                  Call Customer
                </button>
                <button onClick={() => completeDelivery(order._id)}>Complete Delivery</button>
              </>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default DeliveryDashboard;