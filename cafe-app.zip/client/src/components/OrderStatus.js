import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { GoogleMap, LoadScript, Marker } from '@react-google-maps/api';
import { useParams, Link } from 'react-router-dom';
import '../styles/styles.css';

const OrderStatus = () => {
  const { orderId } = useParams();
  const [order, setOrder] = useState(null);
  const [deliveryLocation, setDeliveryLocation] = useState(null);

  useEffect(() => {
    axios
      .get(`http://localhost:5000/order/${orderId}`, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
      })
      .then((response) => {
        setOrder(response.data);
      });

    const interval = setInterval(() => {
      axios
        .get(`http://localhost:5000/delivery/location/${orderId}`, {
          headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
        })
        .then((response) => {
          setDeliveryLocation(response.data);
        });
    }, 5000);

    return () => clearInterval(interval);
  }, [orderId]);

  if (!order) return <div>Loading...</div>;

  return (
    <div className="order-status-container">
      <h2 className="title black">Order Status #{orderId}</h2>
      <div className="order-details">
        <h3>Order Details</h3>
        <p>Customer: {order.name}</p>
        <p>Phone: {order.phone}</p>
        <p>Status: {order.status}</p>
        <div className="order-items">
          {order.items.map((item, index) => (
            <div className="order-item" key={index}>
              <span>
                {item.name} x {item.quantity}
              </span>
              <span>{item.price * item.quantity} THB</span>
            </div>
          ))}
        </div>
        <p>Total: {order.items.reduce((sum, item) => sum + item.price * item.quantity, 0)} THB</p>
      </div>
      {order.status === 'delivering' && deliveryLocation && (
        <div className="delivery-tracking">
          <h3>Track Delivery</h3>
          <LoadScript googleMapsApiKey="your-google-maps-api-key">
            <GoogleMap mapContainerStyle={{ height: '400px', width: '100%' }} center={deliveryLocation} zoom={15}>
              <Marker position={order.location} label="Customer" />
              <Marker position={deliveryLocation} label="Delivery" />
            </GoogleMap>
          </LoadScript>
          <button>Track Delivery</button>
        </div>
      )}
      {order.status === 'delivered' && <p className="success-message">Order Delivered!</p>}
      <Link to="/home">
        <button className="back-button">Back to Home</button>
      </Link>
    </div>
  );
};

export default OrderStatus;