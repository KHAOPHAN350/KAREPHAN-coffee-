import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
import './styles/styles.css';
import firebase from 'firebase/app';
import 'firebase/messaging';
import 'firebase/database';

// Firebase configuration (ต้องแทนที่ด้วย config จริงจาก Firebase Console)
const firebaseConfig = {
  apiKey: 'your-api-key',
  authDomain: 'your-auth-domain',
  projectId: 'your-project-id',
  storageBucket: 'your-storage-bucket',
  messagingSenderId: 'your-messaging-sender-id',
  appId: 'your-app-id',
};
firebase.initializeApp(firebaseConfig);

ReactDOM.render(<App />, document.getElementById('root'));